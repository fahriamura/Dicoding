package com.example.dicoding

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class aboutme : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.aboutme)
        }
}